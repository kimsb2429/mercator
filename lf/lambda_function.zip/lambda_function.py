import textractcaller as tc
import trp.trp2 as t2
import boto3, os, json


def validate_query_set(query_set, valid_answer_set, alias, pages, input_document_key):
    '''
    Queries the document in S3 and checks the returned answers against predetermined valid answers.
    A query set applies to a single alias; if the answer to any one of the queries is correct, validation passes.
    If the returned answer matches any one of the predetermined valid answers, the returned answer is correct.
    '''
    
    # build textract queries
    queries = []
    for query in query_set:
        queries.append(tc.Query(text=query, alias=alias, pages=pages))
        
    # call textract
    region_name = os.environ['RegionName']
    textract = boto3.client('textract', region_name=region_name)
    textract_json = tc.call_textract(
        input_document=input_document_key,
        queries_config=tc.QueriesConfig(queries=queries),
        features=[tc.Textract_Features.QUERIES],
        force_async_api=True,
        boto3_textract_client=textract
    )

    # validate returned json
    t_doc: t2.TDocument = t2.TDocumentSchema().load(textract_json) 
    validation_passed = False
    for page in t_doc.pages:
        query_answers = t_doc.get_query_answers(page=page)
        for x in query_answers:
            validation_passed = validation_passed or (x[1] == alias and x[2] in valid_answer_set)
            print(f"{x[1]},{x[2]}")
            
    # return validation boolean
    return validation_passed

def validate_document(validation_queries, input_document_key):
    '''Validates a document in S3 using textract queries and predetermined valid answers.'''
    
    # validate each query-answer set in the validation file
    validation_result_descs = []
    validation_passed = True
    for item in validation_queries['queries']:
        validation_result = validate_query_set(item['querySet'], item['validAnswerSet'], item['alias'], item['pages'], input_document_key)
        validation_passed = validation_passed and validation_result
    
    # return collective validation status and individual validation results
    return validation_passed

def lambda_handler(event, context):
    '''lambda handler for textractor'''
    
    # read bucket and key from env
    bucket = os.environ['ValidationQueriesS3Bucket']
    validation_queries_key = os.environ['ValidationQueriesS3Key']
    
    # read validation queries and valid answers from s3
    s3 = boto3.resource('s3')
    content_object = s3.Object(bucket, validation_queries_key)
    file_content = content_object.get()['Body'].read().decode('utf-8')
    validation_queries = json.loads(file_content)
    
    # validate document
    input_document_key = "s3://amazon-textract-public-content/blogs/2-pager.pdf" # get from event
    return validate_document(validation_queries, input_document_key)